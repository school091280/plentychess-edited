#pragma once

#include "types.h"
#include "board.h"
#include "bitboard.h"
#include "magic.h"

// Pawn / open-file / piece-square classification utilities used by
// the maneuver strategy, experimental material, and hybrid WDL.
//
// All math here is integer-only.  Move scores and material values are kept
// in PlentyChess's native integer units.

namespace Experimental {

// ---------- precomputed tables ----------
//
// 3x3 neighbor mask per square (8 surrounding squares, clipped at board
// edges).  Used by isActiveKnightFor; replaces an 8-iteration bounds-check
// loop with a single table lookup.
constexpr Bitboard NEIGHBOR_3x3[64] = {
    // rank 0
    0x0000000000000302ULL, 0x0000000000000705ULL, 0x0000000000000E0AULL, 0x0000000000001C14ULL,
    0x0000000000003828ULL, 0x0000000000007050ULL, 0x000000000000E0A0ULL, 0x000000000000C040ULL,
    // rank 1
    0x0000000000030200ULL, 0x0000000000070500ULL, 0x00000000000E0A00ULL, 0x00000000001C1400ULL,
    0x0000000000382800ULL, 0x0000000000705000ULL, 0x0000000000E0A000ULL, 0x0000000000C04000ULL,
    // rank 2
    0x0000000003020300ULL, 0x0000000007050700ULL, 0x000000000E0A0E00ULL, 0x000000001C141C00ULL,
    0x0000000038283800ULL, 0x0000000070507000ULL, 0x00000000E0A0E000ULL, 0x00000000C040C000ULL,
    // rank 3
    0x0000000302030000ULL, 0x0000000705070000ULL, 0x0000000E0A0E0000ULL, 0x0000001C141C0000ULL,
    0x0000003828380000ULL, 0x0000007050700000ULL, 0x000000E0A0E00000ULL, 0x000000C040C00000ULL,
    // rank 4
    0x0000030203000000ULL, 0x0000070507000000ULL, 0x00000E0A0E000000ULL, 0x00001C141C000000ULL,
    0x0000382838000000ULL, 0x0000705070000000ULL, 0x0000E0A0E0000000ULL, 0x0000C040C0000000ULL,
    // rank 5
    0x0003020300000000ULL, 0x0007050700000000ULL, 0x000E0A0E00000000ULL, 0x001C141C00000000ULL,
    0x0038283800000000ULL, 0x0070507000000000ULL, 0x00E0A0E000000000ULL, 0x00C040C000000000ULL,
    // rank 6
    0x0302030000000000ULL, 0x0705070000000000ULL, 0x0E0A0E0000000000ULL, 0x1C141C0000000000ULL,
    0x3828380000000000ULL, 0x7050700000000000ULL, 0xE0A0E00000000000ULL, 0xC040C00000000000ULL,
    // rank 7
    0x0203000000000000ULL, 0x0507000000000000ULL, 0x0A0E000000000000ULL, 0x141C000000000000ULL,
    0x2838000000000000ULL, 0x5070000000000000ULL, 0xA0E0000000000000ULL, 0x40C0000000000000ULL,
};

// Per-file mask (1 << file), used by the open-file scan.
constexpr Bitboard FILE_MASK[8] = {
    0x0101010101010101ULL, 0x0202020202020202ULL,
    0x0404040404040404ULL, 0x0808080808080808ULL,
    0x1010101010101010ULL, 0x2020202020202020ULL,
    0x4040404040404040ULL, 0x8080808080808080ULL,
};

// Returns the number of pawns on the board.
inline int totalPawnCount(const Board* board) {
    return BB::popcount(board->byPiece[Piece::PAWN]);
}

// Returns the number of open files (files with no pawns).  Loops 8 files
// and short-circuits cheaply via the FILE_MASK table.
inline int openFileCount(const Board* board) {
    Bitboard pawns = board->byPiece[Piece::PAWN];
    int openFiles = 0;
    for (int f = 0; f < 8; f++) {
        if ((pawns & FILE_MASK[f]) == 0)
            openFiles++;
    }
    return openFiles;
}

inline int occupiedSquareCount(const Board* board) {
    return BB::popcount(board->byColor[Color::WHITE] | board->byColor[Color::BLACK]);
}

// ---------- maneuver strategy activation ----------

// Spec: more than 11 pawns, zero open files, ply > 40.
// Optimized: a single pawn popcount and short-circuiting file scan.
inline bool maneuverActive(const Board* board, int ply) {
    Bitboard pawns = board->byPiece[Piece::PAWN];
    if (BB::popcount(pawns) <= 11)
        return false;
    // scan 8 files, short-circuit on first non-empty file
    for (int f = 0; f < 8; f++) {
        if (pawns & FILE_MASK[f])
            return false;
    }
    return ply > 40;
}

// Original (pre-maneuver) closed-position quiet-first rule.  Consulted only
// when maneuverActive() is false.  Spec: 12-16 pawns, 0 open files, ply>=38.
inline bool closedPositionQuietBias(const Board* board, int ply) {
    Bitboard pawns = board->byPiece[Piece::PAWN];
    int pawnCount = BB::popcount(pawns);
    if (pawnCount < 12 || pawnCount > 16)
        return false;
    for (int f = 0; f < 8; f++) {
        if (pawns & FILE_MASK[f])
            return false;
    }
    return ply >= 38;
}

// Capture / quiet bias percentages for the original table.
// Returns percentages in integer (e.g. 20 means +20%).
// Maneuver phase: caller should not consult this; bypass the bias entirely.
inline void originalOrderingBias(const Board* board, int& captureBiasPct, int& quietBiasPct) {
    int pawns = BB::popcount(board->byPiece[Piece::PAWN]);
    int openFiles = 0;
    Bitboard pawnBB = board->byPiece[Piece::PAWN];
    for (int f = 0; f < 8; f++) {
        if ((pawnBB & FILE_MASK[f]) == 0)
            openFiles++;
    }

    captureBiasPct = 0;
    quietBiasPct = 0;

    if (pawns < 7) {
        captureBiasPct = 20;
    } else if (pawns <= 9) {
        captureBiasPct = 5;
    } else if (pawns <= 11) {
        // 10-11: no bias
    } else {
        // 12-16 pawns
        if (openFiles == 0) quietBiasPct = 35;
        else if (openFiles == 1) quietBiasPct = 10;
        else if (openFiles == 2) quietBiasPct = 5;
        else quietBiasPct = 1;
    }
}

// One-shot helper for MoveGen: computes both biases from a single scan of
// the board.  Use this in hot paths instead of calling originalOrderingBias
// twice (once for capture bias, once for quiet bias).
inline void computeOrderingBiases(const Board* board, int& captureBiasPct, int& quietBiasPct) {
    Bitboard pawns = board->byPiece[Piece::PAWN];
    int pawnCount = BB::popcount(pawns);
    int openFiles = 0;
    for (int f = 0; f < 8; f++) {
        if ((pawns & FILE_MASK[f]) == 0)
            openFiles++;
    }

    captureBiasPct = 0;
    quietBiasPct = 0;

    if (pawnCount < 7) {
        captureBiasPct = 20;
    } else if (pawnCount <= 9) {
        captureBiasPct = 5;
    } else if (pawnCount <= 11) {
        // 10-11: no bias
    } else {
        // 12-16 pawns
        if (openFiles == 0) quietBiasPct = 35;
        else if (openFiles == 1) quietBiasPct = 10;
        else if (openFiles == 2) quietBiasPct = 5;
        else quietBiasPct = 1;
    }
}

// ---------- piece classification helpers (per color, not stm) ----------

// Knight on the enemy half with friendly pawn support in the surrounding 3x3.
inline bool isActiveKnightFor(const Board* board, Color c, Square s) {
    if (!(board->byPiece[Piece::KNIGHT] & board->byColor[c] & bitboard(s)))
        return false;

    int rank = rankOf(s);
    int advanced = (c == Color::WHITE) ? rank : (7 - rank);
    if (advanced < 3) return false;

    Bitboard ourPawns = board->byPiece[Piece::PAWN] & board->byColor[c];
    return (ourPawns & NEIGHBOR_3x3[s]) != 0;
}

// Bishop whose own-color-complex pawn structure blocks most of its diagonals.
inline bool isTrappedBishopFor(const Board* board, Color c, Square s) {
    if (!(board->byPiece[Piece::BISHOP] & board->byColor[c] & bitboard(s)))
        return false;

    Bitboard ourPawns = board->byPiece[Piece::PAWN] & board->byColor[c];
    Bitboard bishopSquares = getBishopMoves(s, board->byColor[Color::WHITE] | board->byColor[Color::BLACK]);
    return BB::popcount(bishopSquares & ourPawns) >= 3;
}

// Bishop on a long, uncluttered diagonal.
inline bool isGoodOutpostBishopFor(const Board* board, Color c, Square s) {
    if (!(board->byPiece[Piece::BISHOP] & board->byColor[c] & bitboard(s)))
        return false;

    Bitboard ourPawns = board->byPiece[Piece::PAWN] & board->byColor[c];
    Bitboard bishopSquares = getBishopMoves(s, board->byColor[Color::WHITE] | board->byColor[Color::BLACK]);
    return BB::popcount(bishopSquares & ourPawns) <= 1;
}

// ---------- experimental material values (maneuver phase) ----------
// In centipawns.  Used only when maneuverActive(board, ply) is true.

constexpr int EXP_PAWN_VALUE_CP    =   10;
constexpr int EXP_ACTIVE_KNIGHT_CP =  350;
constexpr int EXP_PASSIVE_KNIGHT_CP=  320;
constexpr int EXP_GOOD_BISHOP_CP   =  340;
constexpr int EXP_TRAPPED_BISHOP_CP=  120;
constexpr int EXP_QUEEN_CP         =  790;
constexpr int EXP_ROOK_CP          =  450;

// Returns the experimental material contribution in centipawns summed over
// both colors.  Used by the maneuver-phase evaluation override.
inline int experimentalMaterialCp(const Board* board) {
    int total = 0;
    Bitboard occupied = board->byColor[Color::WHITE] | board->byColor[Color::BLACK];
    for (int c = 0; c < 2; c++) {
        Color color = (Color)c;
        Bitboard pieces = board->byColor[color];

        total += EXP_PAWN_VALUE_CP * BB::popcount(pieces & board->byPiece[Piece::PAWN]);

        Bitboard ourPawns = board->byPiece[Piece::PAWN] & pieces;

        Bitboard knights = pieces & board->byPiece[Piece::KNIGHT];
        while (knights) {
            Square s = popLSB(&knights);
            total += (ourPawns & NEIGHBOR_3x3[s]) ? EXP_ACTIVE_KNIGHT_CP : EXP_PASSIVE_KNIGHT_CP;
        }

        Bitboard bishops = pieces & board->byPiece[Piece::BISHOP];
        while (bishops) {
            Square s = popLSB(&bishops);
            // Compute bishop rays once; the trapped/good thresholds differ
            // but both depend on the same own-pawn-hit count.
            Bitboard rays = getBishopMoves(s, occupied);
            int ownPawnHits = BB::popcount(rays & ourPawns);
            total += (ownPawnHits >= 3) ? EXP_TRAPPED_BISHOP_CP : EXP_GOOD_BISHOP_CP;
        }

        total += EXP_ROOK_CP * BB::popcount(pieces & board->byPiece[Piece::ROOK]);
        total += EXP_QUEEN_CP * BB::popcount(pieces & board->byPiece[Piece::QUEEN]);
    }
    return total;
}

} // namespace Experimental
