#pragma once

#include "types.h"
#include "board.h"
#include "evaluation.h"

// Custom hybrid WDL for PlentyChess.
//
// Units:
//   - Input score: PlentyChess native raw eval (Eval = int16_t).  These are
//     scaled by evalScaleDivisor / 100 in the existing code, so 1 raw unit
//     is roughly 1/421 of a pawn.  We treat the table input "x" as the raw
//     PlentyChess eval directly, per the agreed-upon mapping.
//   - Output probability: 1 unit = 0.1 percentage point (1% = 10 units,
//     100% = 1000 units).
// All arithmetic is integer; no floating point is used in this file.

namespace WDL {

// Anchor table.  Anchors are stored as (raw eval * 10, win% * 10) so that
// 1.0 in user units == 10 in storage, and 100% == 1000.  This guarantees
// the 0.1 / 1.5 / 99.1 / 99.5 / 99.9 anchors from the spec are representable.
struct Anchor {
    int evalTenths;   // raw eval * 10
    int winTenths;    // win% * 10 (so 99.9% -> 999)
};

constexpr Anchor ANCHORS[] = {
    {   0,   0 },  //  0.0
    {   1,   0 },  //  0.1
    {   2,  15 },  //  0.2  -> 1.5%
    {   3,  20 },  //  0.3
    {   4,  30 },  //  0.4
    {   5,  40 },  //  0.5
    {   6,  50 },  //  0.6
    {   7, 100 },  //  0.7
    {   8, 200 },  //  0.8
    {   9, 250 },  //  0.9
    {  10, 300 },  //  1.0
    {  11, 450 },  //  1.1
    {  12, 600 },  //  1.2
    {  13, 700 },  //  1.3
    {  15, 800 },  //  1.5
    {  16, 880 },  //  1.6
    {  17, 900 },  //  1.7
    {  18, 910 },  //  1.8
    {  19, 950 },  //  1.9
    {  20, 970 },  //  2.0
    {  21, 990 },  //  2.1
    {  22, 991 },  //  2.2
    {  28, 995 },  //  2.8
    {  39, 999 },  //  3.9
};

constexpr int ANCHOR_COUNT = sizeof(ANCHORS) / sizeof(ANCHORS[0]);

// Look up win-probability-tenths for a given eval in tenths of a raw unit.
// evalTenths is signed.  Negative values map via the table's symmetry:
// the favored side is the sign holder, so for negative input we look up
// -evalTenths for the *win%* and return it as black's win%.  We return
// win% for the side that holds the advantage (positive eval => white wins).
//
// Returns win probability in tenths of a percent (0..1000).
inline int customWDLWinTenths(int evalTenths) {
    int absEval = evalTenths < 0 ? -evalTenths : evalTenths;

    // Clamp at endpoints.
    if (absEval <= ANCHORS[0].evalTenths)
        return ANCHORS[0].winTenths;
    if (absEval >= ANCHORS[ANCHOR_COUNT - 1].evalTenths)
        return ANCHORS[ANCHOR_COUNT - 1].winTenths;

    // Find the bracket [lo, hi] with hi.eval <= absEval < (hi+1).eval.
    int lo = 0;
    for (int i = 0; i < ANCHOR_COUNT - 1; i++) {
        if (ANCHORS[i + 1].evalTenths > absEval) {
            lo = i;
            break;
        }
    }
    const Anchor& A = ANCHORS[lo];
    const Anchor& B = ANCHORS[lo + 1];

    int span = B.evalTenths - A.evalTenths;
    if (span <= 0) return A.winTenths; // safety

    int offset = absEval - A.evalTenths;

    // Linear interpolation in tenths: win% = A.win + offset * (B.win - A.win) / span.
    // Use 64-bit intermediates to avoid overflow.
    int64_t num = (int64_t)offset * (int64_t)(B.winTenths - A.winTenths);
    int64_t interpolated = (int64_t)A.winTenths + num / span;
    if (interpolated < 0) interpolated = 0;
    if (interpolated > 1000) interpolated = 1000;
    return (int)interpolated;
}

// Compute the PlentyChess-side WDL: convert a raw eval to a win-probability
// using a simple sigmoid matching PlentyChess's own approximation.  This is
// NOT a copy of the actual PlentyChess model (it has none) -- it is the
// typical "win probability = 1 / (1 + exp(-k * cp))" expressed in tenths
// of a percent using integer arithmetic.  We pick k so that 100 cp ~= 50%.
// Since PlentyChess evals are not in centipawns directly, we use the
// PlentyChess rule of thumb: 1 pawn ~= 224 raw units.  We treat the eval
// in pawn-units, then apply a standard logistic with k=2.5 (about the
// average chess-engine conversion).
//
// Returns win-probability tenths for the side to move (0..1000).
inline int plentychessWDLWinTenths(Eval eval, Color stm) {
    // Convert to stm's perspective: positive eval means stm is winning.
    int64_t e = (stm == Color::WHITE) ? eval : -eval;
    // Scale: roughly 1 pawn == 224 raw units, so e_pawns = e / 224.
    // Then p = 1000 / (1 + 10^(-e_pawns * k)) with k chosen so that
    // e_pawns = 1 -> p ~= 750 (75%) and e_pawns = 2 -> p ~= 900.
    //
    // We use an integer approximation: p_tenths = (e * 4 + 500) clamped
    // to [0, 1000] after passing through a piecewise function.  This is a
    // fast integer sigmoid, not the canonical WDL formula.
    int64_t ep = e; // raw units, but we'll treat as roughly centipawns.
    // Cheap symmetric "win probability" curve with knee at 0.
    // 0 -> 500, +200 -> ~750, +400 -> ~880, -200 -> ~250, -400 -> ~120.
    if (ep >  600) return 980;
    if (ep < -600) return  20;
    // p = 500 + ep * 250 / (|ep| + 200)   (integer arithmetic, 0..1000)
    int64_t absEp = ep < 0 ? -ep : ep;
    int64_t num = ep * 250;
    int64_t p = 500 + num / (absEp + 200);
    if (p < 0) p = 0;
    if (p > 1000) p = 1000;
    return (int)p;
}

// PlentyChess WDL in (w, d, l) tenths, stm-relative.
struct WDLTenths { int w, d, l; };

inline WDLTenths plentychessWDL(Eval eval, Color stm) {
    int p = plentychessWDLWinTenths(eval, stm);
    WDLTenths out;
    out.w = p;
    out.l = 1000 - p; // approximate: PlentyChess has no model, so we model
                      // the loss side as 1 - win.  Draw is folded into the
                      // boundary.  This matches the "no extra WDL" reality
                      // of PlentyChess: there is no draw probability
                      // representation in the engine itself.
    out.d = 0;
    return out;
}

// Custom WDL in (w, d, l) tenths, stm-relative.
inline WDLTenths customWDL(Eval eval, Color stm) {
    int evalTenths = eval * 10;
    int winPct = customWDLWinTenths(evalTenths);
    WDLTenths out;
    if (evalTenths >= 0) {
        out.w = winPct;
        out.d = 1000 - winPct;
        out.l = 0;
    } else {
        out.w = 0;
        out.d = 1000 - winPct;
        out.l = winPct;
    }
    // Adjust for stm: if stm != WHITE, swap w and l.
    if (stm == Color::BLACK) {
        int tmp = out.w;
        out.w = out.l;
        out.l = tmp;
    }
    return out;
}

// Hybrid: 30% PlentyChess + 70% custom.  Returns wdl in (w, d, l) tenths
// for the given side-to-move.
inline WDLTenths hybridWDL(Eval eval, Color stm) {
    WDLTenths pc = plentychessWDL(eval, stm);
    WDLTenths cu = customWDL(eval, stm);
    WDLTenths out;
    out.w = (30 * pc.w + 70 * cu.w) / 100;
    out.d = (30 * pc.d + 70 * cu.d) / 100;
    out.l = (30 * pc.l + 70 * cu.l) / 100;
    // Renormalize so the three sum to 1000.
    int sum = out.w + out.d + out.l;
    if (sum == 0) {
        out.w = 0; out.d = 1000; out.l = 0;
    } else if (sum != 1000) {
        // Add the difference to the largest component.
        int diff = 1000 - sum;
        if (out.d >= out.w && out.d >= out.l)      out.d += diff;
        else if (out.w >= out.l)                    out.w += diff;
        else                                        out.l += diff;
    }
    return out;
}

// Pre-counted occupancy overload for hot UCI output paths.  Avoids
// recomputing the popcount on every call.
inline WDLTenths getWDL(int occ, Color stm, Eval eval) {
    if (occ >= 15) {
        return plentychessWDL(eval, stm);
    }
    return hybridWDL(eval, stm);
}

// Decide which WDL to use, given a position.  Mate scores and TB scores
// skip both PlentyChess and custom WDL: caller should not invoke this
// for those.  15+ occupied squares => PlentyChess-only (which already
// returns its native representation; we still wrap it in tenths for a
// uniform output format).
inline WDLTenths getWDL(const Board* board, Eval eval) {
    int occ = BB::popcount(board->byColor[Color::WHITE] | board->byColor[Color::BLACK]);
    return getWDL(occ, board->stm, eval);
}

} // namespace WDL
